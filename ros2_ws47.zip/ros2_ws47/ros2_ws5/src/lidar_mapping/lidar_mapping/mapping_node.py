"""
Import libraries and modules used in the script:

- scipy.spatial.transform.Rotation: Tools for handling 3D rotations and conversions between representations (e.g., Euler angles, quaternions).
- scipy.ndimage.median_filter: Median filtering for noise reduction in grid or sensor data.
- rclpy.node.Node: Base class for creating ROS 2 nodes that communicate within the ROS 2 ecosystem.
- rclpy.time: Utilities for managing time and timestamps in ROS 2, essential for synchronization.
- sensor_msgs.msg.LaserScan: Message type for representing laser scan data from range sensors.
- nav_msgs.msg.OccupancyGrid, Odometry: Message types for occupancy grids (mapping) and robot odometry (movement tracking).
- geometry_msgs.msg.Pose, TransformStamped: Messages for representing robot poses and coordinate frame transformations.
- rclpy.qos: QoSProfile, QoSReliabilityPolicy, QoSHistoryPolicy: Quality of Service (QoS) configurations for controlling ROS 2 topic message delivery.
- tf2_ros: Library for managing TF2 (transform) frames in ROS 2 for coordinate tracking over time.
- tf2_ros.Buffer, TransformListener: Buffer stores transformations, and TransformListener updates the buffer with incoming transforms.
- numpy: Library for numerical computations, array manipulations, and matrix operations.
- math: Standard mathematical functions like trigonometry and exponentiation.
- visualization_msgs.msg.Marker, MarkerArray: Message types for visualizing data in RViz using markers (e.g., points, lines, shapes).
- geometry_msgs.msg.Point: Message type representing 3D points (x, y, z), often used for marker locations or trajectories.
- scipy.spatial.KDTree: Data structure for efficient spatial searches, such as nearest-neighbor queries in mapping[In my case for frontier cells].
"""

from scipy.spatial.transform import Rotation as R
from scipy.ndimage import median_filter  # For noise filtering
from rclpy.node import Node
import rclpy.time
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import OccupancyGrid, Odometry, Path
from geometry_msgs.msg import Pose, TransformStamped, Twist
from rclpy.qos import QoSProfile, QoSReliabilityPolicy, QoSHistoryPolicy
import tf2_ros
from tf2_ros import Buffer, TransformListener
import numpy as np
import math
from visualization_msgs.msg import Marker, MarkerArray
from geometry_msgs.msg import Point
from scipy.spatial import KDTree

class MappingNode(Node):
    def __init__(self):
        """
        
        Initialize the Mapping Node.

        This function sets up the ROS 2 node for building and managing an occupancy grid map. It initializes the map parameters, 
        occupancy grid structure, publishers, subscribers, and TF components required for the mapping process. The node listens 
        to odometry and LIDAR data, updates the map, and publishes the resulting occupancy grid and detected frontiers.

        Attributes:
            robot_x_map, robot_y_map, robot_theta_map: Robot pose in the map frame.
            map_resolution (float): Resolution of the occupancy grid (meters per cell).
            map_width, map_height (int): Dimensions of the occupancy grid (number of cells).
            occupancy_grid (numpy array): Represents the grid, with -1 for unknown, 0 for free, and 100 for occupied cells.
            map_msg (OccupancyGrid): ROS 2 message containing the occupancy grid map information.
            map_publisher (Publisher): Publishes the `OccupancyGrid` message.
            frontier_publisher (Publisher): Publishes the detected frontiers as markers for visualization in RViz.
            tf_buffer (Buffer) and tf_listener (TransformListener): Manage frame transformations.

        References
            - Github : https://github.com/Alynie/turtlebot-packages/blob/master/src/final/final/navigation.py [Line 18 for QOS profile]
            - For Buffer Transform : https://docs.ros2.org/latest/api/tf2_ros/classtf2__ros_1_1Buffer.html
                                   : https://docs.ros.org/en/foxy/Tutorials/Intermediate/Tf2/Writing-A-Tf2-Listener-Py.html [Implementation]
        """
        super().__init__('mapping_node')

        # Robot pose in the map frame
        self.robot_x_map = 0.0
        self.robot_y_map = 0.0
        self.robot_theta_map = 0.0

        self.last_x_map = 0.0
        self.last_y_map = 0.0
        self.publish_threshold = 0.1  # Threshold to publish map updates

        # Map parameters
        self.map_resolution = 0.1  # meters per cell
        self.map_width = 200  # number of cells along the width
        self.map_height = 200  # number of cells along the height
        self.grid_origin = Pose()
        self.grid_origin.position.x = -self.map_width / 2 * self.map_resolution
        self.grid_origin.position.y = -self.map_height / 2 * self.map_resolution

        self.grid_size = (self.map_height, self.map_width)  # Dimensions for grid

        # Initialize occupancy grid: -1 for unknown
        self.occupancy_grid = np.ones((self.map_width, self.map_height), dtype=np.int8) * -1
        

        # Setup OccupancyGrid message
        self.map_msg = OccupancyGrid()
        self.map_msg.header.frame_id = 'map'
        self.map_msg.info.resolution = self.map_resolution
        self.map_msg.info.width = self.map_width
        self.map_msg.info.height = self.map_height
        self.map_msg.info.origin = self.grid_origin

        # Publisher for the map
        self.map_publisher = self.create_publisher(OccupancyGrid, 'map', 20)

        self.path_publisher = self.create_publisher(Path, 'planned_path', 10)
        self.cmd_vel_publisher = self.create_publisher(Twist, '/cmd_vel', 10)
        self.centroid_publisher = self.create_publisher(MarkerArray, 'frontier_centroids', 10)
        self.frontier_publisher = self.create_publisher(MarkerArray, 'frontiers', 10)

        # TF components
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        # Create QoS profiles
        
        odom_qos = QoSProfile(reliability=QoSReliabilityPolicy.BEST_EFFORT, history=QoSHistoryPolicy.KEEP_LAST, depth=10)
        scan_qos = QoSProfile(reliability=QoSReliabilityPolicy.BEST_EFFORT, history=QoSHistoryPolicy.KEEP_LAST, depth=10)

        # Subscriptions

        self.create_subscription(Odometry, '/odom', self.odometry_callback, odom_qos)
        self.create_subscription(LaserScan, '/scan', self.lidar_callback, scan_qos)

        # Broadcast the static map->odom transform
        self.broadcast_map_transform()

    def odometry_callback(self, msg):
        """
        Updates the robot's pose in the map frame based on odometry data.

        This callback processes odometry messages to update the robot's position 
        (x, y) and orientation (theta) in the map frame. The orientation is converted 
        from quaternion to Euler angles to extract the yaw angle (theta).

        Attributes Updated:
            robot_x_map (float): Updated x-coordinate of the robot in the map frame.
            robot_y_map (float): Updated y-coordinate of the robot in the map frame.
            robot_theta_map (float): Updated orientation (yaw) of the robot in the map frame.
        
        """
        self.robot_x_map = msg.pose.pose.position.x
        self.robot_y_map = msg.pose.pose.position.y
        qx, qy, qz, qw = msg.pose.pose.orientation.x, msg.pose.pose.orientation.y, msg.pose.pose.orientation.z, msg.pose.pose.orientation.w
        self.robot_theta_map = R.from_quat([qx, qy, qz, qw]).as_euler('xyz')[2]

        """

         References

        - Scipy Transformation Documentaion: https://docs.scipy.org/doc/scipy/reference/generated/scipy.spatial.transform.Rotation.from_quat.html
        - Github :https://github.com/HanwenCao/Frontier_Exploration/blob/master/my_frontier/scripts/demo.py [Line 78 shows x,y and oreintations ]

        """

    def lidar_callback(self, msg):
        """
        Processes LiDAR scan data to update the occupancy grid and detect frontiers.

        Process:
            1. Check if the transform from "map" to "rplidar_link" is available. If not, skip processing.
            2. Extract the robot's pose in the map frame from the transform.
            3. Filter the scan data using a median filter to reduce noise.
            4. For each valid range reading:
            - Transform the reading from local (robot) coordinates to map coordinates.
            - Convert map coordinates to grid indices.
            - Mark free space along the line from the robot to the detected obstacle using 
                Bresenham's algorithm.
            - Mark the endpoint as an obstacle.
            5. Publish the updated map and detect frontiers.

        Attributes Updated:
            - occupancy_grid (numpy.ndarray): Updated occupancy grid with free and occupied cells.
            - last_x_map (float): Robot's last x-coordinate in the map frame (for distance tracking).
            - last_y_map (float): Robot's last y-coordinate in the map frame.

        Publishes:
            - The updated occupancy grid as a ROS2 OccupancyGrid message.
            - Detected frontiers as a ROS2 MarkerArray message.
        
        """

        if not self.tf_buffer.can_transform("map", "rplidar_link", rclpy.time.Time()):
            self.get_logger().warn("Transform unavailable, skipping scan")
            return

        # Get transform once per scan
        t = self.tf_buffer.lookup_transform("map", "rplidar_link", rclpy.time.Time())
        self.robot_x_map = t.transform.translation.x
        self.robot_y_map = t.transform.translation.y
        qx, qy, qz, qw = t.transform.rotation.x, t.transform.rotation.y, t.transform.rotation.z, t.transform.rotation.w
        self.robot_theta_map = R.from_quat([qx, qy, qz, qw]).as_euler('xyz')[2]

        distance_moved = math.sqrt((self.robot_x_map - self.last_x_map) ** 2 +(self.robot_y_map - self.last_y_map) ** 2)

        # Avoid redundant updates by skipping map updates when the robot has not moved beyond a threshold
        if distance_moved < self.publish_threshold:
            return

        # Apply median filter to reduce noise in LiDAR data
        filtered_ranges = median_filter(msg.ranges, size=5)

        # Iterate over the filtered scan data
        angle = msg.angle_min
        for i, r in enumerate(filtered_ranges):
            if self.is_valid_range(r, msg.range_min, msg.range_max):
                # Calculate local coordinates
                x_local = r * math.cos(angle)
                y_local = r * math.sin(angle)

                # Transform local to map frame
                x_map = self.robot_x_map + (x_local * math.cos(self.robot_theta_map) - y_local * math.sin(self.robot_theta_map))
                y_map = self.robot_y_map + (x_local * math.sin(self.robot_theta_map) + y_local * math.cos(self.robot_theta_map))

                # Convert map coordinates to grid indices
                grid_x = int((x_map - self.grid_origin.position.x) / self.map_resolution)
                grid_y = int((y_map - self.grid_origin.position.y) / self.map_resolution)
                robo_x = int((self.robot_x_map - self.grid_origin.position.x) / self.map_resolution)
                robo_y = int((self.robot_y_map - self.grid_origin.position.y) / self.map_resolution)
                
                # Update the occupancy grid
                if 0 <= grid_x < self.map_width and 0 <= grid_y < self.map_height:
                    # Update free space using Bresenham's algorithm
                    line = self.bresenham(robo_y, robo_x, grid_y, grid_x)
                    for x, y in line[:-1]:
                        if 0 <= x < self.map_width and 0 <= y < self.map_height:
                            self.occupancy_grid[x, y] = 0  # Free space
                    # Mark the last point as an obstacle
                    last_x, last_y = line[-1]
                    if 0 <= last_x < self.map_width and 0 <= last_y < self.map_height:
                        self.occupancy_grid[last_x, last_y] = 100  # Obstacle

            angle += msg.angle_increment
        
        self.publish_map()
        self.last_x_map = self.robot_x_map
        self.last_y_map = self.robot_y_map

        frontier_regions = self.detect_frontiers()
        self.publish_frontiers(frontier_regions)
        self.publish_centroids(frontier_regions)

        """
        References

            - GitHub Repository on world(local) to map: https://github.com/awesomebytes/occupancy_grid_python [Line 92 shows world to map coordinates and i use ]
            - https://automaticaddison.com/ros-2-navigation-tuning-guide-nav2/

        """

    def is_valid_range(self, r, range_min, range_max):
        """
        Checks if the range reading is valid (not an outlier).
        """
        # Reject outliers: values that are either too small or too large
        max_distance = 12.0  # Maximum reasonable distance (in meters)
        if r < range_min or r > range_max or r > max_distance:
            return False
        return True

    def bresenham(self, x1, y1, x2, y2):
        """
        Computes the grid cells traversed by a line using Bresenham's algorithm.

        This function implements Bresenham's line algorithm to determine which cells 
        in a 2D occupancy grid are traversed by a straight line between two points. 
        It is commonly used in robotics for tasks such as marking free and occupied 
        spaces in an occupancy grid.

        Args:
            x1 (int): Starting x-coordinate in the grid.
            y1 (int): Starting y-coordinate in the grid.
            x2 (int): Ending x-coordinate in the grid.
            y2 (int): Ending y-coordinate in the grid.

        Returns:
            list[tuple[int, int]]: A list of (x, y) grid cell coordinates that the 
            line passes through.

         
        """
        line = []
        delta_x = abs(x2 - x1)
        delta_y = abs(y2 - y1)
        s_x = 1 if x2 > x1 else -1
        s_y = 1 if y2 > y1 else -1

        if delta_y > delta_x:
            delta_x, delta_y = delta_y, delta_x
            interchange = True
        else:
            interchange = False

        error = 2 * delta_y - delta_x

        for _ in range(delta_x + 1):
            line.append((x1, y1))
            if error > 0:
                if interchange:
                    x1 += s_x
                else:
                    y1 += s_y
                error -= 2 * delta_x
            if interchange:
                y1 += s_y
            else:
                x1 += s_x
            error += 2 * delta_y

        return line
        """
        Reference:
            - Github :https://github.com/lukovicaleksa/grid-mapping-in-ROS/blob/main/scripts/bresenham.py
            - Github :https://github.com/encukou/bresenham/blob/master/bresenham.py

        """

    def detect_frontiers(self):
        """
        Detects frontier cells in the occupancy grid and groups them into frontier regions based on 8-connected neighbors.

        Frontier cells are free space cells (0) that have at least one adjacent unknown space (-1) in their 8-connected neighborhood.

        The detected frontier cells are then clustered into frontier regions using the `cluster_frontiers` function.

        Returns:
            list: A list of frontier regions, where each region is represented as a list of (x, y) coordinates of frontier cells.
   
        """
        frontier_cells = []
    
        for x in range(1, self.map_width - 1):
            for y in range(1, self.map_height - 1):
                if self.occupancy_grid[x, y] == 0:  # Free space
                    # Check neighbors (8-connected) for unknown space (-1)
                    if any(
                        self.occupancy_grid[x + dx, y + dy] == -1
                        for dx, dy in [
                            (-1, 0), (1, 0), (0, -1), (0, 1),  # N, S, W, E 
                             
                        ]
                    ):
                        frontier_cells.append((x, y))
    
        # Group frontier cells into regions using a clustering algorithm
        frontier_regions = self.cluster_frontiers(frontier_cells)
    
        return frontier_regions
        """
        Reference:

            - Github :https://github.com/SeanReg/nav2_wavefront_frontier_exploration/blob/main/nav2_wfd/wavefront_frontier.py [ Line 221 to 229 ]
            - Github :https://github.com/abdulkadrtr/ROS2-FrontierBaseExplorationForAutonomousRobot/blob/main/autonomous_exploration/autonomous_exploration/control.py   [ Line 152  to 164 ]     
            - Github :https://github.com/adrian-soch/frontier_exploration

        """



    def cluster_frontiers(self, frontier_cells):
        """
        This Function groups frontier cells into larger regions using a dynamic distance-based clustering approach and filters small regions.

        The function first constructs a KDTree from the frontier cells for efficient nearest-neighbor search, then uses a dynamic
        threshold based on the distances between cells to form clusters. The clustering approach grows clusters starting from each
        frontier cell and includes all neighboring cells within the dynamic threshold distance.

        After clusters are formed, small clusters (with fewer than a minimum number of cells) are filtered.

        Returns:
            list: A list of clusters, where each cluster is represented as a list of (x, y) coordinates of frontier cells.

         
        """

        if not frontier_cells:
            return []

        # Creating a KDTree for efficient nearest-neighbor search
        frontier_array = np.array(frontier_cells)
        kdtree = KDTree(frontier_array)

        # Compute dynamic threshold
        distances, _ = kdtree.query(frontier_array, k=2)  # k=2 because the first neighbor is the cell itself
        average_distance = np.median(distances[:, 1])  # Use median to avoid outliers
        dynamic_threshold = max(1.5 * average_distance, self.map_resolution)

        visited = set()
        clusters = []

        def grow_cluster(start_idx):
            cluster = []
            queue = [start_idx]
            while queue:
                idx = queue.pop()
                if idx in visited:
                    continue
                visited.add(idx)
                cluster.append(tuple(frontier_array[idx]))

                # Find neighbors within the dynamic threshold
                neighbors = kdtree.query_ball_point(frontier_array[idx], dynamic_threshold)
                queue.extend(n for n in neighbors if n not in visited)

            return cluster

        # Creating clusters
        for idx in range(len(frontier_cells)):
            if idx not in visited:
                clusters.append(grow_cluster(idx))

        # Filter small clusters (ignore clusters smaller than a minimum size)
        min_cluster_size = 9  # Adjust this value as needed
        filtered_clusters = [cluster for cluster in clusters if len(cluster) >= min_cluster_size]

        return filtered_clusters

        """
        References:

           -Github :https://github.com/TheWorldOfCode/exploration_frontier_2d/blob/master/src/frontier.cpp [on Line 150 uses clustering approach to create a region, so we adapted to use a clustering approach]
        """



    def publish_map(self):
        """
        Publishes the current occupancy grid map to the 'map' topic.

        This method flattens the 2D grid, updates the map message, and
        publishes it with the current timestamp.
        """
        self.map_msg.data = self.occupancy_grid.flatten().tolist()
        self.map_publisher.publish(self.map_msg)
        self.get_logger().info("Map updated.")

 

    def publish_frontiers(self, frontier_regions):
        """
        Publishes frontier regions as RViz markers with a single distinct color for each region.

        This function creates a MarkerArray in ROS to visualize frontier regions in the RViz environment. 
        Each region is assigned a distinct color from a predefined list. The function ensures that if there 
        are more frontier regions than colors available, the colors are cycled.

        Args:
            frontier_regions (list): A list of clusters or frontier regions, where each region is a list of 
                                    (x, y) coordinates of frontier cells.

        """
        marker_array = MarkerArray()

        # Define a list of distinct colors (RGB)
        predefined_colors = [
        
        # Can add more colors for more regions

            (1.0, 0.0, 0.0), # Red
            (0.0, 1.0, 0.0), # Green
            (0.0, 0.0, 1.0), # Blue
            (1.0, 1.0, 0.0), # Yellow
            (1.0, 0.0, 1.0), # Magenta
            (0.0, 1.0, 1.0), # Cyan
            (0.5, 0.5, 0.5), # Gray
            (1.0, 0.5, 0.0), # Orange
            (0.5, 0.0, 0.5), # Purple
            (0.5, 1.0, 0.5), # Light Green
            (0.0, 0.5, 0.0), # Dark Green
            (0.0, 0.0, 0.5), # Navy Blue
            (1.0, 0.75, 0.8), # Pink
            (0.6, 0.4, 0.2), # Brown
            (0.9, 0.9, 0.9), # Light Gray
            (0.2, 0.2, 0.2), # Dark Gray
            (1.0, 0.84, 0.0), # Gold
            (0.75, 0.75, 0.75), # Silver
            (0.5, 0.0, 0.0), # Maroon
            (0.0, 0.5, 0.5), # Teal
            (0.9, 0.9, 0.5), # Beige
            (1.0, 0.63, 0.48), # Coral
            (0.5, 1.0, 0.0), # Lime
            (0.54, 0.17, 0.89), # Indigo
            (0.29, 0.0, 0.51), # Dark Purple
            (0.98, 0.5, 0.45), # Salmon
            (0.0, 1.0, 0.5), # Spring Green
            (0.5, 0.0, 1.0), # Violet
            (0.96, 0.87, 0.7), # Wheat
            (0.0, 0.81, 0.82) # Turquoise
            ]
        
        num_regions = len(frontier_regions)

        # Ensure that the number of colors is at least the number of regions
        if num_regions > len(predefined_colors):
            print("Warning: Not enough predefined colors for all regions. Adding more colors.")
            # Optionally, cycle the colors if there are more regions than colors
            colors = predefined_colors * (num_regions // len(predefined_colors)) + predefined_colors[:num_regions % len(predefined_colors)]
        else:
            colors = predefined_colors[:num_regions]
        
        # Iterate through the frontier regions and assign each a distinct color
        for i, (region, color) in enumerate(zip(frontier_regions, colors)):
            marker = Marker()
            marker.header.frame_id = 'map'
            marker.header.stamp = self.get_clock().now().to_msg()
            marker.ns = 'frontier'
            marker.id = i
            marker.type = Marker.POINTS
            marker.action = Marker.ADD
            marker.pose.orientation.w = 1.0
            marker.scale.x = self.map_resolution
            marker.scale.y = self.map_resolution
            
            # Set the color for the current frontier region
            marker.color.r = color[0]
            marker.color.g = color[1]
            marker.color.b = color[2]
            marker.color.a = 1.0  # Fully opaque

            # Add points for each cell in the region
            for cell in region:
                point = Point()
                point.x = self.grid_origin.position.x + cell[1] * self.map_resolution
                point.y = self.grid_origin.position.y + cell[0] * self.map_resolution
                point.z = 0.0
                marker.points.append(point)

            marker_array.markers.append(marker)

        # Publish the markers
        self.frontier_publisher.publish(marker_array)

        """
        Reference:

            - Github : https://github.com/adrian-soch/frontier_exploration/blob/main/learned_frontier_detector/learned_frontier_detector/learned_frontier_detector.py  [Line 183]
            - ROS MarkerArray documentation: http://docs.ros.org/en/noetic/api/visualization_msgs/html/msg/MarkerArray.html

        """

    def calculate_centroid(self, frontier):
            """ Computes the centroid of a frontier region. """
            x_coords = [cell[0] for cell in frontier]
            y_coords = [cell[1] for cell in frontier]
            return (sum(x_coords) / len(frontier), sum(y_coords) / len(frontier))
    

    def publish_centroids(self, frontier_regions):
        """
        Publishes the centroids of detected frontier regions as a MarkerArray for visualization.
        """
        marker_array = MarkerArray()

        for idx, region in enumerate(frontier_regions):
            centroid_grid = self.calculate_centroid(region)

             
            
            # Convert centroid from grid coordinates to map coordinates
            centroid_x_map = self.grid_origin.position.x + centroid_grid[1] * self.map_resolution
            centroid_y_map = self.grid_origin.position.y + centroid_grid[0] * self.map_resolution

            # Create a marker for each centroid
            marker = Marker()
            marker.header.frame_id = 'map'
            marker.header.stamp = self.get_clock().now().to_msg()
            marker.ns = 'centroids'
            marker.id = idx
            marker.type = Marker.SPHERE
            marker.action = Marker.ADD
            marker.pose.position.x = centroid_x_map
            marker.pose.position.y = centroid_y_map
            marker.pose.position.z = 0.0
            marker.pose.orientation.w = 1.0
            marker.scale.x = 0.2  # Adjust size as needed
            marker.scale.y = 0.2
            marker.scale.z = 0.2
            marker.color.a = 1.0  # Alpha (opacity)
            marker.color.r = 1.0  # Red color
            marker.color.g = 0.0
            marker.color.b = 0.0

            marker_array.markers.append(marker)

            # Debugging logs
            self.get_logger().info(f"Adding centroid marker at: ({centroid_x_map}, {centroid_y_map})")

        # Publish the entire marker array
        self.centroid_publisher.publish(marker_array)
        self.get_logger().info(f"Published {len(marker_array.markers)} centroid markers,")
        if len(marker_array.markers)== 0:
            print("=====================================All the frontiers are explored ======================================")
            print("=====================================All the frontiers are explored ======================================")
            print("=====================================All the frontiers are explored ======================================")
            print("=====================================All the frontiers are explored ======================================")
            print("=====================================All the frontiers are explored ======================================")
            print("=====================================All the frontiers are explored ======================================")
       

    def broadcast_map_transform(self):
        """
        Broadcasts a static transform from 'odom' to 'map'.

        This function broadcasts a static transformation between the 'map' frame   and the 'Odometry' frame 
        to inform other parts of the ROS system about the relationship between these two coordinate frames. 
        The transform is static, meaning it does not change over time.

        The transform is used for localizing the robot in the map.

        """
        br = tf2_ros.StaticTransformBroadcaster(self)
        transform = TransformStamped()
        transform.header.stamp = self.get_clock().now().to_msg()
        transform.header.frame_id = "map"
        transform.child_frame_id = "odom"
        transform.transform.translation.x = 0.0
        transform.transform.translation.y = 0.0
        transform.transform.translation.z = 0.0
        transform.transform.rotation.x = 0.0
        transform.transform.rotation.y = 0.0
        transform.transform.rotation.z = 0.0
        transform.transform.rotation.w = 1.0
        br.sendTransform(transform)

        """
        Reference:
        
            - TF2 in ROS: https://docs.ros.org/en/noetic/api/tf2/html/index.html
            - ROS Static Transform Broadcaster: https://wiki.ros.org/tf2/Tutorials/Writing%20a%20tf2%20static%20broadcaster%20%28Python%29 [ Section 2.1 ]
        """

def main(args=None):
    rclpy.init(args=args)
    node = MappingNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
