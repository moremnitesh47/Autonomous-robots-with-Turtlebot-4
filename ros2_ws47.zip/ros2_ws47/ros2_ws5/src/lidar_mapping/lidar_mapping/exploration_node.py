"""
- rclpy: Import the main `rclpy` library, which provides the core ROS 2 client library for Python.
- geometry_msgs.msg.Twist:Import the `Twist` message type from the `geometry_msgs` package, used to represent linear and angular velocities for commanding the robot.
- geometry_msgs.msg.PoseStamped: Import the `PoseStamped` message type from the `geometry_msgs` package, used to represent a pose with a timestamp and frame of reference.
- visualization_msgs.msg.MarkerArray: Import the `MarkerArray` message type from the `visualization_msgs` package, used to represent an array of visual markers for visualization purposes (e.g., displaying frontier centroids in RViz).
- nav_msgs.msg.Odometry: Import the `Odometry` message type from the `nav_msgs` package, used to represent the robot's pose and velocity as estimated by an odometry source.
- nav_msgs.msg.OccupancyGrid: Import the `OccupancyGrid` message type from the `nav_msgs` package, used to represent a 2D occupancy grid map of the environment.
- nav_msgs.msg.Path: Import the `Path` message type from the `nav_msgs` package, used to represent a sequence of poses forming a planned path for the robot.
- sensor_msgs.msg.LaserScan: Import the `LaserScan` message type from the `sensor_msgs` package, used to represent data from a laser scanner (LiDAR).
- math: Import the standard Python `math` module, providing access to mathematical functions (e.g., `math.hypot`, `math.atan2`).
- numpy: Import the NumPy library, providing support for numerical operations and array manipulation.
- heapq: Import the `heapq` module, providing an implementation of the heap queue algorithm (used for the A* search algorithm).
- scipy.interpolate.splprep, scipy.interpolate.splev: Import the `splprep` and `splev` functions from the `scipy.interpolate` module, used for spline interpolation (path smoothing).
- rclpy.qos.QoSProfile, rclpy.qos.ReliabilityPolicy: These are used to configure the Quality of Service (QoS) settings for communication in ROS 2.  `QoSProfile` bundles various QoS settings, and `ReliabilityPolicy` specifies how reliable the communication should be (e.g., `BEST_EFFORT` means that some data loss is acceptable).

"""

from rclpy.node import Node
import rclpy
from geometry_msgs.msg import Twist, PoseStamped
from visualization_msgs.msg import MarkerArray
from nav_msgs.msg import Odometry, OccupancyGrid, Path
from sensor_msgs.msg import LaserScan
import math
import numpy as np
import heapq
from scipy.interpolate import splprep, splev  # For path smoothing
from rclpy.qos import QoSProfile, ReliabilityPolicy



class ExplorationNode(Node):
    def __init__(self):
        super().__init__('exploration_node')

        """

            This is the constructor for the ExplorationNode class. 
            It initializes all the necessary components for the exploration node, including publishers, subscribers, robot state variables, movement parameters, map parameters, and timers. 
            It sets up communication with other ROS 2 nodes and initializes the state of the robot and the environment.
        
        """


        # Qos profiles
        qos_profile = QoSProfile(reliability=ReliabilityPolicy.BEST_EFFORT,depth=10)

 
        # Publishers and Subscribers
        self.cmd_vel_publisher = self.create_publisher(Twist, '/cmd_vel', 10)
        self.path_publisher = self.create_publisher(Path, '/planned_path', 10)

        self.centroid_subscriber = self.create_subscription(MarkerArray, 'frontier_centroids', self.centroid_callback, 10)
        self.create_subscription(Odometry, '/odom', self.odom_callback, qos_profile)
        self.lidar_subscriber = self.create_subscription(LaserScan, '/scan', self.lidar_callback, 10)
        self.map_subscriber = self.create_subscription(OccupancyGrid, '/map', self.map_callback, 10)
         

        # Robot State
        self.current_pose = None
        self.current_goal = None
        self.frontiers = []
        self.occupancy_grid = None  # To be populated with map data
        self.path = []  # Waypoints for the path

        # Movement Parameters
        self.max_linear_speed = 0.4  # m/s
        self.max_angular_speed = 1.0  # rad/s
        self.goal_reached_threshold = 0.2  # meters
        self.waypoint_threshold = 0.9  # meters

        # Control Gains
        self.linear_kp = 0.8
        self.angular_kp = 2.0

        # Map Parameters (set these appropriately)
        self.map_resolution = 0.1  # meters per cell
        self.map_origin_x = -10  # map origin in meters
        self.map_origin_y = -10  # map origin in meters
        self.map_width = 200  # cells
        self.map_height = 200  # cells
        
        #Clearance from obstacles
        self.clearance_distance=0.24

        # Timer to periodically check and move towards goals
        self.timer = self.create_timer(0.1, self.navigate_to_frontier)  # Increased frequency for smoother motion
        self.replan_timer = self.create_timer(7.0, self.replan_path_if_needed)  # Replan every 10 seconds

        """

            Reference:
                    Subscription and publisher : https://docs.ros.org/en/foxy/Tutorials/Beginner-Client-Libraries/Writing-A-Simple-Py-Publisher-And-Subscriber.html
                    
        """


    def odom_callback(self, msg):

        """

            This function is a callback that is triggered when the node receives a message on the '/odom' topic. 
            It updates the current_pose attribute with the robot's current pose as extracted from the odometry message.
        
            Args:
                msg (nav_msgs.msg.Odometry): The received odometry message.
        
        """

        self.current_pose = msg.pose.pose

    def lidar_callback(self, msg):

        """

            This function is a callback that is triggered when the node receives a message on the '/scan' topic. 
            It stores the latest LiDAR data in the latest_lidar_data attribute for use in obstacle avoidance.
        
            Args:
                msg (sensor_msgs.msg.LaserScan): The received laser scan message.
        
        """

        self.latest_lidar_data = msg  # Store LiDAR data for obstacle avoidance

    def map_callback(self, msg):


        """

            This function is a callback that is triggered when the node receives a message on the '/map' topic. 
            It processes the occupancy grid data from the map message, compares it to the previously stored map (if any), and triggers 
            path replanning if a significant change is detected in the map.
            
            Args:
                msg (nav_msgs.msg.OccupancyGrid): The received occupancy grid message.
        
        """

        new_occupancy_grid = np.array(msg.data).reshape((msg.info.height, msg.info.width))

        # Compare only if we have an existing map
        if self.occupancy_grid is not None:
            # Calculate percentage of changed cells
            changed_cells = np.sum(new_occupancy_grid != self.occupancy_grid)
            total_cells = new_occupancy_grid.size
            change_percentage = (changed_cells / total_cells) * 100

            # Replan only if more than 5% of the map has changed
            if change_percentage > 5:
                self.get_logger().info(f"Significant map change detected ({change_percentage:.2f}%). Replanning path.")
                self.replan_path()
            else:
                self.get_logger().info(f"Minor map changes detected ({change_percentage:.2f}%). No replanning.")

        # Update the stored map
        self.occupancy_grid = new_occupancy_grid



    def centroid_callback(self, msg):

        """

            This function is a callback that is triggered when the node receives a message on the 'frontier\_centroids' topic. 
            The function processes the receivedMarkerArray message, extracts the centroid positions from the markers, and stores 
            them in the self.frontiers list. 
            If there is no current goal set and there are frontiers available, it calls the select_closest_frontier function to choose a new goal.
        
            Args:
                msg (visualization_msgs.msg.MarkerArray): The received message containing an array of frontier markers.

        """

        self.frontiers = []
        for marker in msg.markers:
            centroid = (marker.pose.position.x, marker.pose.position.y)
            self.frontiers.append(centroid)
        
        if not self.current_goal and self.frontiers:
            self.select_closest_frontier()

    def select_closest_frontier(self):

        """

            This function selects the closest reachable frontier from the list of available frontiers (self.frontiers) as the new goal. 
            It calculates the distance to each frontier, sorts them by distance, and then attempts to find a valid path to each frontier using the A* algorithm. 
            Once a reachable frontier is found, it sets the self.current_goal, smooths the path, publishes it, and returns. 
            If no reachable frontiers are found, it clears the current goal.

        """

        if not self.current_pose or not self.frontiers:
            self.get_logger().warn("No pose or frontiers available.")
            return

        robot_x = self.current_pose.position.x
        robot_y = self.current_pose.position.y

        # Always select the closest frontier
        sorted_frontiers = sorted(self.frontiers, key=lambda c: math.hypot(c[0] - robot_x, c[1] - robot_y))

        for frontier in sorted_frontiers:
            start = self.world_to_grid(robot_x, robot_y)
            goal = self.world_to_grid(*frontier)

            if not self.is_valid_cell(goal[0], goal[1],0.04):
                self.get_logger().warn(f"Skipping unreachable frontier at {frontier}.")
                continue

            raw_path = self.astar(start, goal)
            if raw_path:
                self.current_goal = frontier
                self.path = self.smooth_path(raw_path)
                self.publish_path(self.path)
                self.get_logger().info(f"New goal set at: {self.current_goal}")
                return

        self.get_logger().warn("No reachable frontiers found. Stopping exploration.")
        self.current_goal = None




    def navigate_to_frontier(self):

        """

            This function is the core navigation loop, designed to be called periodically by a timer. 
            It checks for a valid navigation goal and a path to that goal. If either is missing, it attempts to select a new frontier. 
            If a valid goal and path exist, it moves the robot towards the next waypoint on the path. If the robot reaches a waypoint, 
            it removes it from the path. 
            If the path is empty, it means the robot has reached the goal, so it clears the goal and selects a new frontier.
        
        """

        if not self.current_goal or not self.path:
            self.get_logger().info("No active goal or path. Selecting new frontier.")
            self.select_closest_frontier()
            return

        if not self.current_pose:
            self.get_logger().warn("No current pose available.")
            return

        robot_x = self.current_pose.position.x
        robot_y = self.current_pose.position.y

        # Move towards the next waypoint
        next_waypoint = self.grid_to_world(*self.path[0])
        distance_to_waypoint = math.hypot(next_waypoint[0] - robot_x, next_waypoint[1] - robot_y)

        if distance_to_waypoint < self.waypoint_threshold:
            self.path.pop(0)
            if not self.path:
                self.get_logger().info(f"Reached goal at: {self.current_goal}. Selecting next frontier.")
                print("The goal might be reached or explored  =======(Inside Navigate frontier)========== ")
                self.current_goal = None
                self.select_closest_frontier()
                return

        self.move_to_point(next_waypoint)




    def move_to_point(self, point):

        """

            -This function calculates and applies the necessary linear and angular velocities to move the robot toward a specified goal point. 
            
            -It uses a proportional controller to adjust the velocities based on the distance and angle to the goal.
             The control effort (velocity) is proportional to the error (distance and angle to the goal). 
            
            -It also incorporates basic obstacle avoidance using LiDAR data.
            
            -The function checks the LiDAR data to detect obstacles in front of the robot. 
             If an obstacle is too close, it triggers an escape maneuver.

            Args:
                point (tuple[float, float]): The (x, y) coordinates of the goal point in the world frame.

            Returns:
                Publishes a Twist command to the /cmd_vel topic to move the robot towards the goal.
        
        """

        robot_x = self.current_pose.position.x
        robot_y = self.current_pose.position.y
        goal_x, goal_y = point

        distance = math.hypot(goal_x - robot_x, goal_y - robot_y)
        angle_to_goal = math.atan2(goal_y - robot_y, goal_x - robot_x)
        yaw = self.quaternion_to_yaw(self.current_pose.orientation)
        angle_diff = self.normalize_angle(angle_to_goal - yaw)

        cmd = Twist()

        if abs(angle_diff) > 0.3:
            cmd.angular.z = max(-self.max_angular_speed, min(self.max_angular_speed, self.angular_kp * angle_diff))
            cmd.linear.x = 0.0
        else:
            cmd.linear.x = min(self.max_linear_speed, self.linear_kp * distance * (1 - abs(angle_diff)))
            cmd.angular.z = max(-self.max_angular_speed, min(self.max_angular_speed, self.angular_kp * angle_diff))

        if self.latest_lidar_data:
            front_ranges = self.latest_lidar_data.ranges[len(self.latest_lidar_data.ranges)//3: 2*len(self.latest_lidar_data.ranges)//3]
            if min(front_ranges) < 0.009:
                self.get_logger().warn("Obstacle detected ahead! Executing escape maneuver.")
                self.execute_escape_maneuver()
                return

        self.cmd_vel_publisher.publish(cmd)

        """

        Reference:
        
                Obsatcle detection/avoidance using the Lidar/scan:[]
                    https://github.com/bhuvanharlapur/Robotics-Mini-Project/blob/master/src/main_code.py
                How to send the velocities to waypoints 
                    https://learn.ubiquityrobotics.com/python_script_1
                Understanding the concepts of Navigation- Basic control, Velocity control, Position control, 
                    https://pyrobot.org/docs/navigation

        """

    def execute_escape_maneuver(self):

        """

            This function is called when the robot detects an obstacle too close in front of it (based on LiDAR data in move_to_point). 
            It commands the robot to rotate in place to try and escape the obstacle. 
            It publishes a Twist message with zero linear velocity and a positive angular velocity, initiating the rotation. 
            It also sets a timer to call stop_rotation after a short delay to stop the rotation.
        
        """

        twist = Twist()
        twist.linear.x = 0.0  # No backward motion since TurtleBot4 can't reverse
        twist.angular.z = 1.0  # Rotate in place to escape obstacle
        self.cmd_vel_publisher.publish(twist)

        # Create a timer to stop rotation after 1.5 seconds
        self.escape_timer = self.create_timer(1.5, self.stop_rotation)

        """

        This repo has move forward, stop, turn towards goal functions which are useful for certain scenarios so we implemented an escape maneuver 
                    https://github.com/bhuvanharlapur/Robotics-Mini-Project/blob/master/src/main_code.py

        """
         

    def stop_rotation(self):

        """
            This function is called by the timer set in execute_escape_maneuver. 
            It commands the robot to stop rotating by publishing a Twist message with zero linear and angular velocities. 
            It also cancels the timer to prevent it from being called again.
        
        """

        twist = Twist()
        twist.linear.x = 0.0
        twist.angular.z = 0.0
        self.cmd_vel_publisher.publish(twist)
        self.get_logger().info("Escape maneuver complete. Stopped rotation.")

        # Cancel the timer after stopping rotation to prevent repeated calls
        if hasattr(self, 'escape_timer'):
            self.escape_timer.cancel()

        """

        This repo has move forward, stop, turn towards goal functions which are useful for certain scenarios so we implemented an escape maneuver 
                    https://github.com/bhuvanharlapur/Robotics-Mini-Project/blob/master/src/main_code.py

        """


     
 

    def replan_path(self):
        """

            This function is responsible for replanning the robot's path to the current goal. 
            It checks for a valid pose and goal, implements a cooldown timer to prevent excessive replanning, 
            converts the pose and goal to grid coordinates, calls the A* algorithm to generate a new path, smooths the path, 
            publishes it for visualization, and updates the last replan timestamp. 
            If the A* algorithm fails to find a path, it finds the Next available goal and attempts to select a new frontier.
        
        """

        if not self.current_pose or not self.current_goal:
            return

        start = self.world_to_grid(self.current_pose.position.x, self.current_pose.position.y)
        goal = self.world_to_grid(*self.current_goal)
        raw_path = self.astar(start, goal)

        if raw_path:
            self.path = self.smooth_path(raw_path)
            self.publish_path(self.path)
            self.get_logger().info("Path replanned, regardless of map update.")
        else:
            self.get_logger().warn("Failed to replan path. Selecting new frontier.")
            self.current_goal = None
            self.select_closest_frontier()





    def astar(self, start, goal):

        """
        Perform A* pathfinding algorithm to find a path from start to goal.

        This implementation includes clearance checking and a fallback to the closest
        reachable cell if the goal is unreachable. It uses a Manhattan distance heuristic
        and considers both orthogonal and diagonal movements.

        Args:
            start (tuple): The starting position as a tuple of (x, y) coordinates.
            goal (tuple): The goal position as a tuple of (x, y) coordinates.

        Returns:
            list: A list of tuples representing the path from start to goal (or closest
                reachable point). Each tuple contains (x, y) coordinates. Returns an
                empty list if no path is found
        """
        def heuristic(a, b):
            return abs(a[0] - b[0]) + abs(a[1] - b[1])

        def cost(current, neighbor):
            base_cost = 1.414 if (neighbor[0] - current[0]) * (neighbor[1] - current[1]) != 0 else 1
            clearance = self.get_clearance(neighbor[0], neighbor[1])
            clearance_penalty = 10 if clearance == 0 else 2.0 / clearance
            return base_cost + clearance_penalty

        open_set = [(0, start)]
        came_from = {}
        g_score = {start: 0}
        f_score = {start: heuristic(start, goal)}

        neighbors = [(-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (-1, 1), (1, -1), (1, 1)]

        closest_to_goal = start
        min_distance_to_goal = heuristic(start, goal)

        while open_set:
            _, current = heapq.heappop(open_set)
            if current == goal and self.is_valid_cell(goal[0], goal[1], self.clearance_distance):
                return self.reconstruct_path(came_from, current)

            current_distance = heuristic(current, goal)
            if current_distance < min_distance_to_goal:
                closest_to_goal = current
                min_distance_to_goal = current_distance

            for dx, dy in neighbors:
                neighbor = (current[0] + dx, current[1] + dy)
                if self.is_valid_cell(neighbor[0], neighbor[1], self.clearance_distance):
                    tentative_g_score = g_score[current] + cost(current, neighbor)
                    if neighbor not in g_score or tentative_g_score < g_score[neighbor]:
                        came_from[neighbor] = current
                        g_score[neighbor] = tentative_g_score
                        f_score[neighbor] = tentative_g_score + heuristic(neighbor, goal)
                        heapq.heappush(open_set, (f_score[neighbor], neighbor))

        if closest_to_goal != start:
            self.get_logger().warn(f"Goal unreachable. Navigating to closest reachable cell at {closest_to_goal}.")
            return self.reconstruct_path(came_from, closest_to_goal)

        return []
    
        """

         The Astar algorithm for Path Planning used from this repositiory and restructured for our use.
                Reference:  https://github.com/Chrisbelefantis/A-Star-Algorithm/blob/master/Astar-Algorithm.py#L246 [Line 246 to 308]
         Also used Pygame to keep improving the parametrs for clearance and inflation radius in repository of @moremnitesh47
                Reference: 


            
        """

   



    def smooth_path(self, path):

        """

            This function takes a path (list of grid cells) and smooths it using spline interpolation. 
            It uses the SciPy library to fit a spline to the path and then evaluates the spline at a higher resolution to generate a smoother path. 
            It also checks if the smoothed waypoints are valid (not in obstacles) before adding them to the final smoothed path.
        
            Args:
                path (list[tuple[int, int]]): A list of (x, y) grid cell coordinates representing the original path.

            Returns:
                list[tuple[int, int]]: A list of (x, y) grid cell coordinates representing the smoothed path.

        """

        if len(path) < 3:  # Ensure there are at least 3 points for cubic spline
            return path  # Return the original path if not enough points

        x_coords, y_coords = zip(*path)

        try:
            tck, _ = splprep([x_coords, y_coords], s=2)
            u_new = np.linspace(0, 1, num=len(path) * 5)
            smooth_x, smooth_y = splev(u_new, tck)

            smoothed_path = [(int(x), int(y)) for x, y in zip(smooth_x, smooth_y) if self.is_valid_cell(int(x), int(y), 0.29)]
            return smoothed_path
        except Exception as e:
            self.get_logger().warn(f"Path smoothing failed: {e}")
            return path  # Fallback to original path if smoothing fails
        


    #############----This code is for lesss Computational cost and can used for less dynamic environment while the other one is robust and fast---###########
    # def replan_path(self):
    #     if not self.current_pose or not self.current_goal:
    #         return

    #     # Check if the last replan was too recent
    #     current_time = self.get_clock().now().seconds_nanoseconds()[0]
    #     if hasattr(self, 'last_replan_time') and (current_time - self.last_replan_time < 3):  # 3-second cooldown
    #         self.get_logger().info("Replanning skipped to avoid frequent updates.")
    #         return

    #     # Proceed with replanning
    #     start = self.world_to_grid(self.current_pose.position.x, self.current_pose.position.y)
    #     goal = self.world_to_grid(*self.current_goal)
    #     raw_path = self.astar(start, goal)

    #     if raw_path:
    #         self.path = self.smooth_path(raw_path)
    #         self.publish_path(self.path)
    #         self.get_logger().info("Path replanned due to map update or obstacle detection.")
    #         self.last_replan_time = current_time  # Update last replan timestamp
    #     else:
    #         self.get_logger().warn("Failed to replan path. Selecting new frontier.")
    #         print("==========Replan path failed============")
    #         print("==========Selecting New Frontier============")
    #         self.current_goal = None
    #         self.select_closest_frontier()


    #########################----Just for switching between different modes of replan-----##########################################

    def publish_path(self, path):


        """

            This function takes a planned path (a list of grid cells) and publishes it as a nav_msgs.msg.Path message. 
            The Path message is then visualized in RViz, a 3D visualization tool for ROS. 
            This allows you to see the planned path of the robot in the RViz environment.
        
            Args:
                path (list[tuple[int, int]]): A list of (x, y) grid cell coordinates representing the planned path.

        """

        path_msg = Path()
        path_msg.header.frame_id = "map"
        current_time = self.get_clock().now().to_msg()
        path_msg.header.stamp = current_time

        for cell in path:
            pose = PoseStamped()
            pose.header.frame_id = "map"
            pose.header.stamp = current_time
            pose.pose.position.x, pose.pose.position.y = self.grid_to_world(*cell)
            pose.pose.orientation.w = 1.0
            path_msg.poses.append(pose)

        self.path_publisher.publish(path_msg)
        self.get_logger().info("Path published to RViz.")
        """
        Reference:
                Path_msg(): https://github.com/ros2/common_interfaces/blob/rolling/nav_msgs/msg/Path.msg

        """



    def reconstruct_path(self, came_from, current):
        """

            This function takes the came_from dictionary (generated by the A* algorithm) and the current cell (the goal or closest reachable cell) as input. 
            It reconstructs the path by tracing back from the current cell to the start cell, using the came_from dictionary to determine the predecessor of each cell in the path. 
            The resulting path is then reversed to obtain the correct order from start to goal.        
        
            Args:
                came_from (dict[tuple[int, int], tuple[int, int]]): A dictionary mapping each grid cell to its predecessor in the path.
                current (tuple[int, int]): The current grid cell (the goal or closest reachable cell).

            Returns:
                list[tuple[int, int]]: A list of (x, y) grid cell coordinates representing the reconstructed path from start to goal.

        """
        path = [current]
        while current in came_from:
            current = came_from[current]
            path.append(current)
        path.reverse()
        return path
    
    def replan_path_if_needed(self):
        """

            This function is designed to be called periodically (likely via a timer). 
            It checks if there is a current navigation goal set for the robot. If a goal exists, it triggers the replan_path function to recalculate the path to that goal. 
            This ensures that the robot's path is updated regularly, even if the environment hasn't changed, allowing for adjustments and corrections
        
        """
        if self.current_goal:
            self.get_logger().info("Periodic path replanning triggered.")
            print("==========Replaning path for Better Path(def(replan path if needed))===========")
            self.replan_path()
        

    def is_valid_cell(self, x, y, inflation_radius):
        """

            This function checks whether a given grid cell (x, y) is valid, meaning it is within the map bounds and not occupied by an obstacle, considering an inflation radius around the cell. 
            This function is used to determine if a cell is safe for the robot to navigate to.
        
            Args:
                x (int): The x-coordinate of the grid cell.
                y (int): The y-coordinate of the grid cell.
                inflation_radius (float): The radius (in meters) to inflate obstacles by.

            Returns:
                bool: True if the cell is valid (within bounds and not occupied), False otherwise.

        """
        if self.occupancy_grid is None:
            self.get_logger().warn("Occupancy grid is not available.")
            return False

        if 0 <= x < self.map_width and 0 <= y < self.map_height:
            radius_in_cells = int(inflation_radius / self.map_resolution)
            x_min, x_max = max(0, x - radius_in_cells), min(self.map_width, x + radius_in_cells + 1)
            y_min, y_max = max(0, y - radius_in_cells), min(self.map_height, y + radius_in_cells + 1)

            if np.any(self.occupancy_grid[y_min:y_max, x_min:x_max] == 100):
                return False
            return True
        return False

    def get_clearance(self, x, y):
        """
            This function calculates the distance to the nearest obstacle from a given grid cell (x, y) in the occupancy grid. 
            It checks a neighborhood around the cell and returns the minimum distance to an occupied cell (value of 100 in the occupancy grid).        
        
            Args:
                x (int): The x-coordinate of the grid cell.
                y (int): The y-coordinate of the grid cell.

            Returns:
                float: The distance to the nearest obstacle, or radius_in_cells if no obstacles are found within the search radius.
        
        """
        if self.occupancy_grid[x, y] == 100:
            return 0

        radius_in_cells = int(self.clearance_distance / self.map_resolution)
        x_min, x_max = max(0, x - radius_in_cells), min(self.map_width, x + radius_in_cells + 1)
        y_min, y_max = max(0, y - radius_in_cells), min(self.map_height, y + radius_in_cells + 1)
        subgrid = self.occupancy_grid[y_min:y_max, x_min:x_max]
        obstacle_indices = np.where(subgrid == 100)

        if len(obstacle_indices[0]) > 0:
            dx = obstacle_indices[0] - (y - y_min)
            dy = obstacle_indices[1] - (x - x_min)
            return np.min(np.sqrt(dx**2 + dy**2))
        return radius_in_cells

    def world_to_grid(self, x, y):
        """

            This function converts coordinates from the world frame (meters) to the grid frame (cell indices). 
            It uses the map origin (map_origin_x, map_origin_y) and the map resolution (map_resolution) to perform the conversion.

            Args:
                x (float): The x-coordinate in the world frame (meters).
                y (float): The y-coordinate in the world frame (meters).

            Returns:
                Tuple[int, int]: The (grid_x, grid_y) indices of the corresponding grid cell.

        """

        grid_x = int((x - self.map_origin_x) / self.map_resolution)
        grid_y = int((y - self.map_origin_y) / self.map_resolution)
        return (grid_x, grid_y)
    

        """
        References:
            Understanding the grid conversions---section Coordinate conversion
                https://classes.engineering.wustl.edu/cse550/a02.php
        """
         

    def grid_to_world(self, grid_x, grid_y):
        """

            This function converts coordinates from the grid frame (cell indices) to the world frame (meters). 
            It uses the map origin (map_origin_x, map_origin_y) and the map resolution (map_resolution) to perform the conversion        
        
            Args:
                grid_x (int): The x-index of the grid cell.
                grid_y (int): The y-index of the grid cell.

            Returns:
                tuple[float, float]: The (x, y) coordinates of the corresponding location in the world frame (meters).

        """
        x = self.map_origin_x + grid_x * self.map_resolution
        y = self.map_origin_y + grid_y * self.map_resolution
        return (x, y)
    
        """
        References:
            Understanding the grid conversions---section Coordinate conversion.
                https://classes.engineering.wustl.edu/cse550/a02.php
        """

    def quaternion_to_yaw(self, q):

        """
        Convert a quaternion to a yaw angle (rotation around z-axis).

        This function takes a quaternion representation of orientation and
        extracts the yaw component, which represents the rotation around the
        vertical (z) axis.

        Args:
            q (Quaternion): A quaternion object with attributes w, x, y, and z.
        """
        siny_cosp = 2 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z)
        return math.atan2(siny_cosp, cosy_cosp)
    


    def normalize_angle(self, angle):
        """
        Normalize an angle to be within the range [-π, π].

        This function takes an angle (in radians) and normalizes it to ensure
        it falls within the range of -π to π. It does this by repeatedly
        adding or subtracting 2π until the angle is within the desired range.

        Args:
            angle (float): The input angle in radians.

        Returns:
            float: The normalized angle in radians, within the range [-π, π].
        """
        while angle > math.pi:
            angle -= 2 * math.pi
        while angle < -math.pi:
            angle += 2 * math.pi
        return angle


def main(args=None):
    rclpy.init(args=args)
    node = ExplorationNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
