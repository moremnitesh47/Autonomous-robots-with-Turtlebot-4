from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import ExecuteProcess

def generate_launch_description():
    return LaunchDescription([
        # Mapping Node
        Node(
            package='lidar_mapping',
            executable='mapping_node',  # Python node script
            name='mapping',
            output='screen',
             
        ),

        Node(
            package='lidar_mapping',
            executable='exploration_node', 
            name='explorer',
            output='screen',
             
        ),

        # RVIZ2 with preconfigured file
        ExecuteProcess(
            cmd=['rviz2', '-d', '/home/nitesh/Downloads/ros2_ws5/src/lidar_mapping/rviz/mapping_config.rviz'],
            output='screen'
        )
    ])
